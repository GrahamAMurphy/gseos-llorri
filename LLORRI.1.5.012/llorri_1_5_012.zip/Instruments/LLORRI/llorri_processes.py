dIDtoProcess = {
0x2756: "NULL process", 
0x276e: "DEFAULT process", 
0x6bec: "analog-process",
0xa9fe: "command-process",
0xab52: "telemetry-process",
0xbcc8: "image-process",
0xdd2c: "flash-not-for-writing",
0xdef8: "science-process",
0x0000: "Unassigned" 
}
